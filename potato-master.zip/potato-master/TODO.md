#. Separate DOM-Events from Non-Dom Events (dom events should be bound on each template render while non-Dom Events can be bound only on construction)
#. Solve model binding initialization problem
#. Give a nice spec to event DSL